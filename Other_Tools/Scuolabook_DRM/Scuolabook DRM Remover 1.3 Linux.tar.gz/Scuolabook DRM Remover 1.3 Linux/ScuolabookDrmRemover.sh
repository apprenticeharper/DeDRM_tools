#!/bin/bash
if [ `getconf LONG_BIT` = "64" ]; then
	./sdr64qt4
else
	./sdr32qt4
fi

