How-to:
1) Make sure you can read all PDF files on Scuolabook Reader.
2) Run Scuolabook DRM Remover.
3) Decrypt your books.

Note:
It is recommended to use Scuolabook version 3.0.3 and refuse all updates
because the encryption algorithm may change making this tool useless.

Hex
