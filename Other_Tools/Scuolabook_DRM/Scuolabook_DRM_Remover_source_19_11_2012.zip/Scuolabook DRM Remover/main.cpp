// Scuolabook DRM Remover v1.0
// by HEX (nov 2012)
//
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <openssl/aes.h>
#include <openssl/md5.h>
#include "utility.h"


struct FileHeader {
	uint8	magic[4];
	uint32	size;
};

uint8 unknowArray1[16] = {0x4A, 0x21, 0x79, 0xBC, 0xAD, 0x1C, 0xB5, 0x3C, 0xFF, 0xAE, 0x16, 0x75, 0x54, 0x65, 0x41, 0x18};

static bool decryptBook(const char *fileName, const char *userName, uint8 commonHash[16]);


int main(int argc, char *argv[])
{
	char userName[128], machineId[64], code[64];

	if(!(
		printIntro() &&
		readHkcuRegKey("Software\\Hoplo\\Scuolabook\\login", "username", userName, sizeof(userName)) &&
		getMachineId(machineId) &&
		readHkcuRegKey("Software\\Roaming\\reader", "code", code, sizeof(code))
		)
	) {
		printf("\n");
		system("pause");
		return 1;
	}
	printf("Username: %s\n\n", userName);
	
	uint8 machineIdMd5[MD5_DIGEST_LENGTH];
	strcat(machineId, code);
	MD5((uint8*)machineId, strlen(machineId), machineIdMd5);
	for(unsigned i = 0; i < 16; i++) machineIdMd5[i] += unknowArray1[i];

	int errors = 0;
	if(argc <= 1) {
		printf("Decrypting all installed books...\n");
		char *books[1024];
		getAllBooks(userName, books);
		for(int i = 0; i < 1024; i++) {
			if(books[i] == 0) break;
			errors += (decryptBook(books[i], userName, machineIdMd5) == false);
			delete [] books[i];
		}
	} else {
		//Decrypt books passed on the command line
		for(int i = 1; i < argc; i++) {
			errors += (decryptBook(argv[i], userName, machineIdMd5) == false);
		}
	}

	printf("\nErrors: %i\n\n", errors);
	system("pause");
	return errors;
}


bool decryptBook(const char *fileName, const char *userName, uint8 commonHash[16])
{
	//Read file
	uint8 *fileData;
	unsigned fileSize;
	if(!readFile(fileName, &fileData, fileSize)) return false;

	FileHeader *fileHeader = (FileHeader*)fileData;

	//File size check
	fileHeader->size = big2littleEndian(fileHeader->size);
	if((fileSize < 35) || (fileHeader->size >= fileSize - 7) || (fileHeader->size < fileSize - 40)) {
		printf("Error: could not decrypt %s\n", fileName);
		delete [] fileData;
		return false;
	}
		
	//Make AES initVector
	uint8 initTable[64], initVector[64];
	makeInitTable(fileHeader->magic, initTable);
	makeInitVector(fileHeader->magic, initTable, initVector);

	uint8 unknowArray2[128] = {}, unknowArray2Md5[MD5_DIGEST_LENGTH];
	memcpy(unknowArray2, initVector, 64);
	uint32 userNameLenght = strlen(userName);
	memcpy(unknowArray2 + 64, userName, (userNameLenght > 64) ? 64 : userNameLenght);
	MD5(unknowArray2, 128, unknowArray2Md5);

	//Make AES userKey
	uint8 userKey[32];
	memcpy(userKey, unknowArray2Md5, 16);
	memcpy(userKey + 16, commonHash, 16);

	//Decrypt
	unsigned decryptedFileSize = fileSize - 8;
	uint8 *decryptedFileData = new uint8[decryptedFileSize];
	AES_KEY aesKey;
	AES_set_decrypt_key(userKey, 32 * 8, &aesKey);
	AES_cbc_encrypt(fileData + 8, decryptedFileData, decryptedFileSize, &aesKey, initVector, AES_DECRYPT);
		
	unsigned drmHeaderSize = (((decryptedFileData[0] << 8) + decryptedFileData[1]) << 8) + decryptedFileData[2];
	uint8 *pdfData = decryptedFileData + drmHeaderSize;
	unsigned pdfSize = decryptedFileSize - drmHeaderSize;

	char pdfFileName[1024] = "DECRYPTED - ";
	const char *pdfNameBegin = strrchr(fileName, '\\');
	strcat(pdfFileName, pdfNameBegin ? pdfNameBegin + 1 : fileName);

	FILE *file = fopen(pdfFileName, "wb");
	if(file == 0) {
		printf("Error: could not open \"%s\" for writing\n", pdfFileName);
	} else {
		fwrite(pdfData, 1, pdfSize, file);
		fclose(file);
		printf("\"%s\" decrypted\n", fileName);
	}

	delete [] decryptedFileData;
	delete [] fileData;

	return true;
}
