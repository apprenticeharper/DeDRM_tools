// Scuolabook DRM Remover v1.0
// by HEX (nov 2012)
//
#define WIN32_LEAN_AND_MEAN
#define WINVER WindowsXP
#define _WIN32_WINNT WindowsXP
#include <stdio.h>
#include <string.h>
#include <windows.h>
#include <userenv.h>
#include "utility.h"


bool printIntro()
{
	char *intro[] = {
		"\xC9\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBB\n",
		"\xBA Scuolabook DRM Remover v1.0 \xBA\n",
		"\xBA      by HEX (nov 2012)      \xBA\n",
		"\xC8\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xCD\xBC\n\n"
	};

	for(int i = 0; i < 4; i++) {
		for(int j = 0; j < 22; j++) printf(" ");
		printf(intro[i]);
	}
	char version[32];
	if(!readHkcuRegKey("Software\\Hoplo\\Scuolabook", "version", version, sizeof(version))) return false;
	
	printf("WARNING: this program has been tested only with Scuolabook version 2.0.1,\n", version);
	printf("         it could not work with yours\n\n");
	printf("Current Scuolabook version: %s\n", version);

	return true;
}

bool readHkcuRegKey(const char *key, const char *value, char *out, unsigned lenght)
{
	HKEY hkey;
	LONG status;

	status = RegOpenKeyEx(HKEY_CURRENT_USER, key, 0, KEY_QUERY_VALUE, &hkey);
	if(status != ERROR_SUCCESS) {
		printf("Error: \"HKEY_CURRENT_USER\\%s\" not found\n", key);
		return false;
	}

	memset(out, 0, lenght);
	status = RegQueryValueEx(hkey, value, 0, 0, (LPBYTE)out, (LPDWORD)&lenght);
	if(status != ERROR_SUCCESS) {
		printf("Error: \"HKEY_CURRENT_USER\\%s\" -> \"%s\" not found\n", key, value);
		RegCloseKey(hkey);
		return false;
	}

	RegCloseKey(hkey);
	return true;
}

bool getMachineId(char *machineId)
{
	typedef void(__stdcall *SETHWPROC)(BOOL, BOOL, BOOL);
	typedef const char*(__stdcall *GETIDPROC)();
	typedef int(__stdcall *MIDRWPROC)(const char *, const char *);

	HINSTANCE hMachineId = LoadLibrary("MachineID.dll");
	if(hMachineId == 0) {
		printf("Error: could not load MachineID.dll\n");
		return false;
	}

	MIDRWPROC MID_R = (MIDRWPROC)GetProcAddress(hMachineId, "MID_R");
	GETIDPROC GetMachineID = (GETIDPROC)GetProcAddress(hMachineId, "GetMachineID");
	SETHWPROC SetHardware = (SETHWPROC)GetProcAddress(hMachineId, "SetHardware");

	MID_R("HOPLO SRL", "zxhg1q+6h44xcIWyvrhOClnRqmSMXzYh7rCjevCEursRfc7hhH2JeMTxRLR5XJpFwvo2h6uxzmx6qTpS/WVebkxoZy6nXeXG3pd2h3T+zqFkj+YWvplL+P677MmFk91GR+dphbMxHNI6tD7aSFq8rFsQutrHjPErHGd5VTmIsDQ=");
	SetHardware(FALSE, TRUE, TRUE);

	strcpy(machineId, GetMachineID());

	FreeLibrary(hMachineId);
	return true;
}

bool readFile(const char *fileName, uint8 **fileData, unsigned &fileSize)
{
	FILE *file = fopen(fileName, "rb");
	if(!file) {
		printf("Error: could not open \"%s\"\n", fileName);
		return false;
	}

	fseek(file, 0, SEEK_END);
	fileSize = ftell(file);
	fseek(file, 0, SEEK_SET);

	*fileData = new uint8[fileSize];
	fread(*fileData, 1, fileSize, file);
	fclose(file);

	return true;
}

uint32 big2littleEndian(uint32 n)
{
	uint8 *x = (uint8*) &n;
	return (((((x[0] << 8) + x[1]) << 8) + x[2]) << 8) + x[3];
}

void makeInitTable(uint8 magic[4], uint8 initTable[64])
{
	uint8 n0 = magic[0] >> 4;
	uint8 n1 = (magic[1] >> 7) + 2 * (magic[0] & 0xF);
	uint8 n2 = (magic[1] >> 2) & 0x1F;
	uint8 n3 = (magic[2] >> 5) + 8 * (magic[1] & 3);
	uint8 n4 = magic[2] & 0x1F;

	uint8 v74 = 0;
	uint8 v83 = 0;
	do {
		uint8 v15 = v74;
		uint8 v17 = 8 * v15 + 8;
		uint8 v16 = 0;
		uint8 *v18 = initTable + 8 * v74;
		do {
			uint8 v19 = v17 + v16;
			uint8 v20 = n4 + n0 * (v17 + v16) * (v17 + v16) + (v19 - 1) * n1 + (v19 - 3) * n3;
			uint8 v21 = (v19 - 2) * n2;
			v19 -= 4;
			v19 = v19 * v83;
			
			v15 = v20 + v21 + v19;
			*v18 = v15;
			v16++;
			v18++;
			v83 = v15;
		} while (v16 != 8);
		v74++;
	} while(v74 != 8);
}

void makeInitVector(uint8 magic[4], const uint8 initTable[64], uint8 initVector[64])
{
	uint32 n1 = magic[3] & 0x80;
	uint32 n2 = magic[3] & 0x40;
	uint32 n3 = magic[3] & 0x3F;

	sint32 v23 = n3 & 7;
	sint32 v22 = n3 >> 3; 
	int index = 0;
	
	do {
		while ( 1 )
		{
			initVector[index] = initTable[8 * v23 + v22];
			if(n1) {
				v23++;
				if(v23 == 8) v23 = 0;
LABEL_17:
				if(n2) goto LABEL_18;
				goto LABEL_23;
			}
			v23--;
			if(v23 != -1) goto LABEL_17;
			
			v23 = 7;
			if(n2) {
LABEL_18:
				v22++;
				if(v22 == 8) v22 = 0;
				goto LABEL_19;
			}
LABEL_23:
			v22--;
			if(v22 == -1) break;
LABEL_19:
			index++;
			if(index == 64) goto LABEL_25;
		}
		v22 = 7;
		index++;
	} while(index != 64);
LABEL_25:
	return;
}

bool getAllBooks(const char *userName, char *books[1024])
{
	HANDLE hToken = 0;
	char findMask[1024];
	DWORD findMaskLenght = 1024;

	OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &hToken);
	GetUserProfileDirectory(hToken, findMask, &findMaskLenght);
	strcat(findMask, "\\.scuolabook\\");
	strcat(findMask, userName);
	strcat(findMask, "\\books\\*.pdf");

	CloseHandle(hToken);

	HANDLE hFindFile;
	WIN32_FIND_DATA findData;
	hFindFile = FindFirstFile(findMask, &findData);

	if (hFindFile == INVALID_HANDLE_VALUE) {
      printf ("Error: could not search for books in \"%s\"\n", findMask);
	  books[0] = 0;
	  return false;
	} else {
		unsigned count = 0;
		unsigned pathLenght = strlen(findMask) - 5;
		do {
			books[count] = new char[1024];
			strcpy(books[count], findMask);
			strcpy(books[count] + pathLenght, findData.cFileName);
			count++;
		} while(FindNextFile(hFindFile, &findData) != 0);

		FindClose(hFindFile);
		books[count] = 0;
   }

	return true;
}
