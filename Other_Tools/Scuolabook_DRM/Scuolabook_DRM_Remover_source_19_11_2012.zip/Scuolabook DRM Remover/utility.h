// Scuolabook DRM Remover v1.0
// by HEX (nov 2012)
//
#pragma once

typedef signed char				sint8;
typedef unsigned char			uint8;
typedef signed int				sint32;
typedef unsigned int			uint32;
typedef unsigned long long int	uint64;


bool	printIntro();
bool	readHkcuRegKey(const char *key, const char *value, char *out, unsigned lenght);
bool	readUsername(char *userName, unsigned lenght);
bool	readCode(char *code, unsigned lenght);
bool	getMachineId(char *machineId);
bool	readFile(const char *fileName, uint8 **fileData, unsigned &fileSize);
uint32	big2littleEndian(uint32 n);
void	makeInitTable(uint8 magic[4], uint8 initTable[64]);
void	makeInitVector(uint8 magic[4], const uint8 initTable[64], uint8 initVector[64]);
bool	getAllBooks(const char *userName, char *books[1024]);