#include <QDir>
#include <QDirIterator>
#include <QFileDialog>
#include <QListWidgetItem>
#include <QMessageBox>
#include "scuolabookdrmremover.h"
#include "decrypt.h"

ScuolabookDrmRemover::ScuolabookDrmRemover(QWidget *parent): QMainWindow(parent)
{
	ui.setupUi(this);
}

ScuolabookDrmRemover::~ScuolabookDrmRemover()
{

}

void ScuolabookDrmRemover::showScuolabookInfo()
{
	QString versionText("Scuolabook version: ");
	QString usernameText("Current login user: ");
	versionText += g_version;
	usernameText += g_username;
	ui.versionLabel->setText(versionText);
	ui.usernameLabel->setText(usernameText);

	QDirIterator dirIterator(QDir(g_booksDir, "*.pdf"), QDirIterator::Subdirectories);
	while (dirIterator.hasNext())
	{
		QListWidgetItem *item = new QListWidgetItem;
		item->setToolTip(dirIterator.next());
		item->setText(dirIterator.fileName());
		ui.bookList->addItem(item);
	}
}

void ScuolabookDrmRemover::on_decryptButton_clicked()
{
	QList<QListWidgetItem*> list = ui.bookList->selectedItems();
	if (list.length() == 0)
	{
		QMessageBox::information(this, "Scuolabook DRM Remover", "Select a book first");
	}
	else if (list.length() == 1)
	{
		QString filename = list[0]->toolTip();
		QString out = QDir::homePath();
		out += "/";
		out += list[0]->text();
		out = QFileDialog::getSaveFileName(this, "Save file", out, "Portable Document Format (*.pdf)");
		if (out.isNull()) return;
		decryptBook(filename.toLatin1(), out.toLatin1());
	}
	else
	{
		QString outDir = QDir::homePath();
		outDir = QFileDialog::getExistingDirectory(this, "Open directory", outDir);
		if (outDir.isNull()) return;

		QString filename, out;
		for (int i = 0; i < list.length(); i++)
		{
			filename = list[i]->toolTip();
			out = outDir;
			out += "/";
			out += list[i]->text();
			decryptBook(filename.toLatin1(), out.toLatin1());
		}
	}
	return;
}


void ScuolabookDrmRemover::on_decryptAllButton_clicked()
{
	for (int i = 0; i < ui.bookList->count(); i++)
	{
		ui.bookList->item(i)->setSelected(true);
	}
	on_decryptButton_clicked();
}
