#ifndef SCUOLABOOKDRMREMOVER_H
#define SCUOLABOOKDRMREMOVER_H

#if QT_VERSION >= 0x050000
#include <QtWidgets/QMainWindow>
#else
#include <QMainWindow>
#endif

#include "ui_scuolabookdrmremover.h"

class ScuolabookDrmRemover : public QMainWindow
{
	Q_OBJECT

public:
	ScuolabookDrmRemover(QWidget *parent = 0);
	~ScuolabookDrmRemover();
	void showScuolabookInfo();

public slots:
	void on_decryptButton_clicked();
	void on_decryptAllButton_clicked();

private:
	Ui::ScuolabookDrmRemoverClass ui;
};

#endif // SCUOLABOOKDRMREMOVER_H
