#include <stdio.h>
#include <stdlib.h>
#include <openssl/aes.h>
#include <openssl/md5.h>
#include "decrypt.h"
#include "utility.h"

#ifndef WIN32
#include <QtNetwork>
#endif

#pragma pack(push, 1)
struct FileHeader
{
	uint8	magic[4];
    int32	size;
};
#pragma pack(pop)

const uint8 data1[16] = {0x4A, 0x21, 0x79, 0xBC, 0xAD, 0x1C, 0xB5, 0x3C, 0xFF, 0xAE, 0x16, 0x75, 0x54, 0x65, 0x41, 0x18};
static uint8 machineIdHash[MD5_DIGEST_LENGTH];

static uint32 big2littleEndian(uint32 n);
static void makeInitTable(uint8 magic[4], uint8 initTable[64]);
static void makeInitVector(uint8 magic[4], const uint8 initTable[64], uint8 initVector[64]);

bool initDecryption1()
{
#ifdef WIN32
	char machineId[64] = {};
	if (!loadMachineID()) return false;
	SetHardware(FALSE, TRUE, TRUE);
	strcpy(machineId, GetMachineID());
	unloadMachineID();

	/*QSettings settings2(QSettings::NativeFormat, QSettings::UserScope, "Roaming", "reader");
	errorMsg(settings2.fileName());
	if (!settings.contains("code"))
	{
		errorMsg("Can't read the machine code");
		return false;
	}

	int machineIdLenght = strlen(machineId);
	QString code = settings.value("code").toString();
	if (code.length() > (64 - machineIdLenght))
	{
		QString text = "Unexpected machine code lenght: ";
		text += code.length();
		errorMsg(text);
		return false;
	}
	memcpy(machineId + machineIdLenght, code.toLatin1(), code.length());*/

	HKEY hReaderCodeKey;
	LONG status = RegOpenKeyEx(HKEY_CURRENT_USER, TEXT("Software\\Roaming\\reader"), 0, KEY_QUERY_VALUE, &hReaderCodeKey);
	if (status != ERROR_SUCCESS)
	{
		errorMsg("Can't read the registry key Software\\Roaming\\reader");
		return false;
	}
	
	int machineIdLenght = strlen(machineId);
	int codeLenght = 64 - machineIdLenght;
	status = RegQueryValueExA(hReaderCodeKey, "code", 0, 0, (LPBYTE) (machineId + machineIdLenght), (LPDWORD) &codeLenght);
	if(status != ERROR_SUCCESS)
	{
		errorMsg("Can't read the registry value Software\\Roaming\\reader->code");
		return false;
	}
	RegCloseKey(hReaderCodeKey);
	MD5((uint8*) machineId, strlen(machineId), machineIdHash);
#else
	char mac[128] = {};
	QList<QNetworkInterface> list = QNetworkInterface::allInterfaces();
    QList<QNetworkInterface>::iterator i = list.begin();
    while(i != list.end())
	{
        QNetworkInterface &interface = *i;
        QByteArray hardwareAddress = i->hardwareAddress().toLatin1();
        if(strcmp(hardwareAddress.data(), "00:00:00:00:00:00") != 0)
		{
            QByteArray interfaceName = interface.name().toLatin1();
            if(strstr(interfaceName.data(), "eth") || strstr(interfaceName.data(), "en"))
			{
                strcpy(mac, hardwareAddress.data());
				break;
			}
		}
        i++;
	}
	MD5((uint8*) mac, strlen(mac), machineIdHash);
#endif
	for(unsigned i = 0; i < 16; i++)
	{
		machineIdHash[i] += data1[i];
	}

	return true;
}

bool decryptBook1(const char *filename, const char *out)
{
	//Read the book file
	uint8 *fileData;
	int fileSize;
	if (!readFile(filename, &fileData, fileSize)) return false;

	FileHeader *fileHeader = (FileHeader*) fileData;

	//File size check
	fileHeader->size = big2littleEndian(fileHeader->size);
	if((fileSize < 35) || (fileHeader->size >= fileSize - 7) || (fileHeader->size < fileSize - 40))
	{
		QString text = "Can't decrypt ";
		text += filename;
		errorMsg(text);
		return false;
	}
		
	//Make AES initVector
	uint8 initTable[64], initVector[64];
	makeInitTable(fileHeader->magic, initTable);
	makeInitVector(fileHeader->magic, initTable, initVector);

	uint8 data2[128] = {}, bookHash[MD5_DIGEST_LENGTH];
    memcpy(data2, initVector, 64);
	strncpy((char*) data2 + 64, g_username.toLatin1(), 64);
	MD5(data2, 128, bookHash);

	//Make AES userKey
	uint8 userKey[32];
	memcpy(userKey, bookHash, 16);
	memcpy(userKey + 16, machineIdHash, 16);

	//Decryption
	int decryptedFileSize = fileSize - 8;
	uint8 *decryptedFileData = new uint8[decryptedFileSize];
	AES_KEY aesKey;
	AES_set_decrypt_key(userKey, 32 * 8, &aesKey);
	AES_cbc_encrypt(fileData + 8, decryptedFileData, decryptedFileSize, &aesKey, initVector, AES_DECRYPT);
		
	unsigned drmHeaderSize = (((decryptedFileData[0] << 8) | decryptedFileData[1]) << 8) | decryptedFileData[2];
	uint8 *pdfData = decryptedFileData + drmHeaderSize;
	unsigned pdfSize = decryptedFileSize - drmHeaderSize;
	
	writeFile(out, pdfData, pdfSize);
	delete [] decryptedFileData;
	delete [] fileData;
	return true;
}

uint32 big2littleEndian(uint32 n)
{
	uint8 *x = (uint8*) &n;
	return (((((x[0] << 8) | x[1]) << 8) | x[2]) << 8) | x[3];
}

void makeInitTable(uint8 magic[4], uint8 initTable[64])
{
	uint8 n0 = magic[0] >> 4;
	uint8 n1 = (magic[1] >> 7) + 2 * (magic[0] & 0xF);
	uint8 n2 = (magic[1] >> 2) & 0x1F;
	uint8 n3 = (magic[2] >> 5) + 8 * (magic[1] & 3);
	uint8 n4 = magic[2] & 0x1F;

	uint8 v74 = 0;
	uint8 v83 = 0;
	do {
		uint8 v15 = v74;
		uint8 v17 = 8 * v15 + 8;
		uint8 v16 = 0;
		uint8 *v18 = initTable + 8 * v74;
		do {
			uint8 v19 = v17 + v16;
			uint8 v20 = n4 + n0 * (v17 + v16) * (v17 + v16) + (v19 - 1) * n1 + (v19 - 3) * n3;
			uint8 v21 = (v19 - 2) * n2;
			v19 -= 4;
			v19 = v19 * v83;
			
			v15 = v20 + v21 + v19;
			*v18 = v15;
			v16++;
			v18++;
			v83 = v15;
		} while (v16 != 8);
		v74++;
	} while(v74 != 8);
}

void makeInitVector(uint8 magic[4], const uint8 initTable[64], uint8 initVector[64])
{
	uint32 n1 = magic[3] & 0x80;
	uint32 n2 = magic[3] & 0x40;
	uint32 n3 = magic[3] & 0x3F;

	int32 v23 = n3 & 7;
	int32 v22 = n3 >> 3; 
	int index = 0;
	
	do {
		while ( 1 )
		{
			initVector[index] = initTable[8 * v23 + v22];
			if(n1) {
				v23++;
				if(v23 == 8) v23 = 0;
LABEL_17:
				if(n2) goto LABEL_18;
				goto LABEL_23;
			}
			v23--;
			if(v23 != -1) goto LABEL_17;
			
			v23 = 7;
			if(n2) {
LABEL_18:
				v22++;
				if(v22 == 8) v22 = 0;
				goto LABEL_19;
			}
LABEL_23:
			v22--;
			if(v22 == -1) break;
LABEL_19:
			index++;
			if(index == 64) goto LABEL_25;
		}
		v22 = 7;
		index++;
	} while(index != 64);
LABEL_25:
	return;
}
