#include <stdio.h>
#include <QMessageBox>
#include "utility.h"

#ifdef WIN32
HINSTANCE hMachineIdLib;
MIDRWPROC MID_R;
GETIDPROC GetMachineID;
SETHWPROC SetHardware;

bool loadMachineID()
{
	hMachineIdLib = LoadLibrary(TEXT("MachineID.dll"));
	if (hMachineIdLib == NULL)
	{
		errorMsg("Can't find or load MachineID.dll");
		return false;
	}

	MID_R = (MIDRWPROC) GetProcAddress(hMachineIdLib, "MID_R");
	GetMachineID = (GETIDPROC) GetProcAddress(hMachineIdLib, "GetMachineID");
	SetHardware = (SETHWPROC) GetProcAddress(hMachineIdLib, "SetHardware");
	MID_R("HOPLO SRL", "zxhg1q+6h44xcIWyvrhOClnRqmSMXzYh7rCjevCEursRfc7hhH2JeMTxRLR5XJpFwvo2h6uxzmx6qTpS/WVebkxoZy6nXeXG3pd2h3T+zqFkj+YWvplL+P677MmFk91GR+dphbMxHNI6tD7aSFq8rFsQutrHjPErHGd5VTmIsDQ=");
	return true;
}

void unloadMachineID()
{
	FreeLibrary(hMachineIdLib);
}
#endif

void errorMsg(const QString &text)
{
	QMessageBox::critical(0, "Scuolabook DRM Remover", text);
}

bool readFile(const char *filename, uint8 **fileData, int &fileSize)
{
	FILE *file = fopen(filename, "rb");
	if (!file)
	{
		QString text = "Can't open ";
		text += filename;
		errorMsg(text);
		return false;
	}
	fseek(file, 0, SEEK_END);
	fileSize = ftell(file);
	fseek(file, 0, SEEK_SET);
	*fileData = new uint8[fileSize];
	fread(*fileData, 1, fileSize, file);
	fclose(file);
	return true;
}

bool writeFile(const char *filename, uint8 *fileData, int fileSize)
{
	FILE *file = fopen(filename, "wb");
	if (!file)
	{
		QString text = "Can't create ";
		text += filename;
		errorMsg(text);
		return false;
	}
	fwrite(fileData, 1, fileSize, file);
	fclose(file);
	return true;
}
