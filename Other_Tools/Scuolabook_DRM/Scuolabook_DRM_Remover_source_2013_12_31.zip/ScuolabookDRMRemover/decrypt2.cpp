#include <stdlib.h>
#include <string.h>
#include <openssl/md5.h>
#include <QDir>
#include <QList>
#include <QSettings>
#include <QString>
#include "decrypt.h"
#include "utility.h"

#ifndef WIN32
#include <QtNetwork>
#endif

static QList<QVariant> bookDescList; // from <username>_history.ini
static uint8 key1[MD5_DIGEST_LENGTH];
static uint8 charToHexArray[256];

static bool computeSessionIdHash(uint8 *sessionIdHash);
static bool computeMachineIdHash(uint8 *machineIdHash);
static void initStringToHexArray();
static uint64 hexStringToInteger64(const uint8 string[16]);
static void hexStringToHash(const uint8 string[32], uint8 hash[16]);
static bool getMagicNumber(const char *bookName, uint8 *fileData, int fileSize, uint32 &magic);
static uint8 *memsearch(uint8 *ptr1, int size1, uint8 *ptr2, int size2);
static uint8 *nextline(uint8 *ptr);
static unsigned int numlength(const uint8 *ptr);

bool initDecryption2()
{
	initStringToHexArray();

	// Session ID hash
	uint8 sessionIdHash[MD5_DIGEST_LENGTH];
	if (!computeSessionIdHash(sessionIdHash)) return false;

	// Machine ID hash
	uint8 machineIdHash[MD5_DIGEST_LENGTH];
	if (!computeMachineIdHash(machineIdHash)) return false;

	// XOR
	for (int i = 0; i < MD5_DIGEST_LENGTH; i++)
	{
		key1[i] = machineIdHash[i] ^ sessionIdHash[i];
	}

	QString historyFile = QDir::homePath();
	historyFile += "/.scuolabook/";
	historyFile += g_username;
	historyFile += "_history.ini";
    QSettings history(historyFile, QSettings::IniFormat);
	if (!history.contains("booksList"))
	{
		errorMsg("Can't read the history file, log into Scuolabook Reader and ensure all books are downloaded");
		return false;
    }
    bookDescList = history.value("booksList").toList();

	return true;
}

bool decryptBook2(const char *bookIn, const char *bookOut)
{
	QDir bookDir(bookIn);
	bookDir.cdUp();
	QByteArray bookName = bookDir.dirName().toLatin1();

	// Read the book
	uint8 *fileData;
	int fileSize;
	if (!readFile(bookIn, &fileData, fileSize)) return false;
	if (fileSize < 53)
	{
		QString text = bookName;
		text += " is not a valid book";
		errorMsg(text);
		return false;
	}

	uint32 MAGIC;
	if (!getMagicNumber(bookName, fileData, fileSize, MAGIC)) return false;

	// Fix the pdf xref table and the object numbers
	uint8 *fileEnd = fileData + fileSize;
	uint8 *ptr = fileData;
	while (1)
	{
		uint8 *ptrNew;
		ptrNew = memsearch(ptr, fileEnd - ptr, (uint8*) "xref\x0D\x0A", 6);
        if (ptrNew == NULL) break; // file end
		ptr = ptrNew + 6; // skip "xref"

		while (1)
		{
			unsigned int start = 0, len = 0;
			if (*ptr < '0' || *ptr > '9') break; // xref table end
			sscanf((char*) ptr, "%u %u", &start, &len); //xref table offset start and length
			ptr = nextline(ptr);
		
			unsigned int end = start + len;
			for (unsigned int i = start; i < end; i++)
			{
				unsigned int off, gen;
				sscanf((char *) ptr, "%u %u", &off, &gen);
				if (off != 0)
				{
					// fix offset
					off ^= MAGIC;
					if (off >= (unsigned) fileSize) // invalid offset
					{
						QString text = "Can't decrypt ";
						text += bookName;
						errorMsg(text);
						delete [] fileData;
						return false;
					}
					sprintf((char*) ptr, "%010u", off);
					ptr[10] = ' ';
					/*
						fix object number
						the code try to overwrite the old object number if it
						can't the pdf must be rebuilt...
					*/
					uint8 *obj = fileData + off;
					char format[16];
					unsigned oldObjNumLength = numlength(obj);
					if (oldObjNumLength == 0) // invalid offset
					{
						QString text = "Can't decrypt ";
						text += bookName;
						errorMsg(text);
						delete [] fileData;
						return false;
					}
					sprintf(format, "%%0%uu", oldObjNumLength);
					sprintf((char*) obj, format, i); // i = correct obj number
					obj[oldObjNumLength] = ' ';
					if (oldObjNumLength != numlength(obj))
					{
						QString text = "Error: not enough space to fix obj at offset ";
						text += QString::number(off);
						text += "\n";
						text += bookName;
						text += " must be rebuilt but this operation is not supported... (for now)";
						errorMsg(text);
						delete [] fileData;
						return false;
					}
				}
				ptr += 20;
			}
		}
	}
						
	writeFile(bookOut, fileData, fileSize);
	delete [] fileData;
	return false;
}

static bool computeSessionIdHash(uint8 sessionIdHash[MD5_DIGEST_LENGTH])
{
#ifdef WIN32
	QString metadataFile = QDir::homePath();
	metadataFile += "/.scuolabook/metadata.ini";
	QSettings settings(metadataFile, QSettings::IniFormat);
#else
    QSettings settings(QSettings::NativeFormat, QSettings::UserScope, "Hoplo", "Scuolabook");
#endif
	if (!settings.contains("login/sessionID"))
	{
		errorMsg("Can't read the session ID, log into Scuolabook Reader and restart the application");
		return false;
	}
	QByteArray sessionId = settings.value("login/sessionID").toString().toLatin1();
	MD5((uint8*) sessionId.data(), strlen(sessionId.data()), sessionIdHash);
	return true;
}

static bool computeMachineIdHash(uint8 machineIdHash[MD5_DIGEST_LENGTH])
{
#ifdef WIN32
	if (!loadMachineID()) return false;
	SetHardware(FALSE, TRUE, TRUE);
	char machineId[64] = {};
	strcpy(machineId, GetMachineID());
	MD5((uint8*) machineId, strlen(machineId), machineIdHash);
	unloadMachineID();
#else
    char mac[128] = {};
    QList<QNetworkInterface> list = QNetworkInterface::allInterfaces();
    QList<QNetworkInterface>::iterator i = list.begin();
    while(i != list.end())
    {
        QNetworkInterface &interface = *i;
        QByteArray hardwareAddress = i->hardwareAddress().toLatin1();
        if(strcmp(hardwareAddress.data(), "00:00:00:00:00:00") != 0)
        {
            QByteArray interfaceName = interface.name().toLatin1();
            if(strstr(interfaceName.data(), "eth") || strstr(interfaceName.data(), "en"))
            {
                strcpy(mac, hardwareAddress.data());
                break;
            }
        }
        i++;
    }
    MD5((uint8*) mac, strlen(mac), machineIdHash);
#endif
	return true;
}

static void initStringToHexArray()
{
	for (int i = 0; i < 256; i++)
	{
		charToHexArray[i] = 0;
	}
	uint8 n = 0;
	for (int i = '0'; i <= '9'; i++)
	{
		charToHexArray[i] = n++;
	}
	n = 10;
	for (int i = 'A'; i <= 'F'; i++)
	{
		charToHexArray[i] = n++;
	}
	n = 10;
	for (int i = 'a'; i <= 'f'; i++)
	{
		charToHexArray[i] = n++;
	}
}

static void hexStringToHash(const uint8 string[32], uint8 hash[16])
{
	for (int i = 0; i < 16; i++)
	{
		hash[i] = charToHexArray[string[i << 1]] << 4 | charToHexArray[string[(i << 1) + 1]];
	}
}

static uint64 hexStringToInteger64(const uint8 string[16])
{
	uint64 n = 0;
	for (int i = 0; i < 16; i++)
	{
		n = (n << 4) | charToHexArray[string[i]];
	}
	return n;
}

static bool getMagicNumber(const char *bookName, uint8 *fileData, int fileSize, uint32 &magic)
{
	// Read the book key
	uint8 key2[MD5_DIGEST_LENGTH];
	QByteArray strKey2;
    QList<QVariant>::iterator it = bookDescList.begin();
	while (it != bookDescList.end())
	{
		QList<QVariant> bookDesc = it->toList();
        QByteArray tmp = bookDesc[0].toString().toLatin1();
		if (strcmp(tmp.data(), bookName) == 0)
		{
			strKey2 = bookDesc[49].toString().toLatin1();
			break;
		}
		it++;
	}
	if (strlen(strKey2.data()) == 0)
	{
		QString text = "Can't read the book key of \"";
		text += bookName;
		text += "\",\n log into Scuolabook Reader and ensure the book is fully downloaded";
		errorMsg(text);
		return false;
	}
	if (strlen(strKey2.data()) != 32)
	{
		QString text = "Invalid book key for";
		text += bookName;
		errorMsg(text);
		return false;
	}
	hexStringToHash((uint8*) strKey2.data(), key2);

	uint64 key3 = 0; // aka Key to muPDF
	for (int i = 0; i < 8; i++)
	{
		((uint8*) &key3)[7 - i] = key2[i + 8] ^ key1[i + 8]; 
	}
	
	// Decrypt the header
	uint8 *header = fileData + 11; // 42 bytes
	int x = fileSize & 0x7F;
	for (int i = 0; i < 42; i++)
	{
		header[i] ^= x;
		x = (x + 1) & 0x7F;
	}
    uint64 key4 = hexStringToInteger64(header + 26);
	memset(header, '0', 42); // zero the header out
	
	magic = key3 % key4;
	return true;
}

static uint8 *memsearch(uint8 *ptr1, int size1, uint8 *ptr2, int size2)
{
	for (int i = 0; i < size1; i++)
	{
		if (memcmp(ptr1, ptr2, size2) == 0)
		{
			return ptr1;
		}
		ptr1++;
	}
	return NULL;
}

static uint8 *nextline(uint8 *ptr)
{
	while (ptr[0] != '\x0D' || ptr[1] != '\x0A')
	{
		ptr++;
	}
	ptr += 2;
	return ptr;
}

static unsigned int numlength(const uint8 *ptr)
{
	unsigned int length = 0;
	while (*ptr >= '0' && *ptr <= '9')
	{
		ptr++;
		length++;
	}
	return length;
}
