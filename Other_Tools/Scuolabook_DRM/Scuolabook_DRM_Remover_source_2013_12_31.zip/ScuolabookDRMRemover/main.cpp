#include <QMessageBox>
#include <QtPlugin>
#include "scuolabookdrmremover.h"
#include "decrypt.h"

#if QT_VERSION >= 0x050000
#include <QtWidgets/QApplication>
#else
#include <QApplication>
#endif

#if defined(WIN32) && defined(STATIC)
Q_IMPORT_PLUGIN(QWindowsIntegrationPlugin)
#endif

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	ScuolabookDrmRemover w;
	w.show();
    if (detectScuolabook() && initDecryption())
	{
		w.showScuolabookInfo();
		return a.exec();
	}

	return 1;
}
