#pragma once

#ifdef _WIN32
#define WIN32_LEAN_AND_MEAN
#define WINVER WindowsXP
#define _WIN32_WINNT WindowsXP
#include <stdio.h>
#include <string.h>
#include <windows.h>
#include <userenv.h>
typedef void(__stdcall *SETHWPROC)(BOOL, BOOL, BOOL);
typedef const char*(__stdcall *GETIDPROC)();
typedef int(__stdcall *MIDRWPROC)(const char *, const char *);
extern MIDRWPROC MID_R;
extern GETIDPROC GetMachineID;
extern SETHWPROC SetHardware;
bool loadMachineID();
void unloadMachineID();
#endif

typedef signed char int8;
typedef unsigned char uint8;
typedef signed int int32;
typedef unsigned int uint32;
typedef unsigned long long int uint64;

class QString;

void errorMsg(const QString &text);
bool readFile(const char *filename, uint8 **fileData, int &fileSize);
bool writeFile(const char *filename, uint8 *fileData, int fileSize);