#pragma once
#include <QString>

bool detectScuolabook();
bool initDecryption();
bool decryptBook(const char *bookIn, const char *bookOut);

//Globals initialized by detectScuolabook()
extern QString g_version;
extern QString g_username;
extern QString g_booksDir;