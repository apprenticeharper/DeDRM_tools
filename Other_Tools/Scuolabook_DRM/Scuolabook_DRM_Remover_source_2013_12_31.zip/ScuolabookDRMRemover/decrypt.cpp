#include <QDir>
#include <QSettings>
#include <QString>
#include <stdlib.h>
#include "utility.h"

QString g_version, g_username, g_booksDir;

/*
	Decryption method:
	- 1 = Scuolabook Reader 2.0.1 - 2.1.6
	- 2 = Scuolabook Reader 3.0+
*/
int decryptionMethod = 0;

extern bool initDecryption1();
extern bool decryptBook1(const char *bookIn, const char *bookOut);
extern bool initDecryption2();
extern bool decryptBook2(const char *bookIn, const char *bookOut);

bool detectScuolabook()
{
	QString metadataFile = QDir::homePath();
	metadataFile += "\\.scuolabook\\metadata.ini";
    QSettings *settings = new QSettings(metadataFile, QSettings::IniFormat);
	if (!settings->contains("version"))
	{
		delete settings;
		settings = new QSettings(QSettings::NativeFormat, QSettings::UserScope, "Hoplo", "Scuolabook");
		if (!settings->contains("version"))
        {
            errorMsg("Can't detect Scuolabook Reader (not installed or unsupported version)");
            delete settings;
            return false;
		}
	}
    g_version = settings->value("version").toString();

	if (!settings->contains("login/username"))
	{
		errorMsg("Can't detect the user name, log into Scuolabook Reader and restart the application");
		return false;
	}
	g_username = settings->value("login/username").toString();

	g_booksDir = QDir::homePath();
	g_booksDir += "/.scuolabook/";
	g_booksDir += g_username;
	g_booksDir += "/books";
	
	double version = atof(g_version.toLatin1());
	if (version < 3.0) decryptionMethod = 1;
	else decryptionMethod = 2;
	
	delete settings;
	return true;
}

bool initDecryption()
{
	switch (decryptionMethod)
	{
	case 1: return initDecryption1();
	case 2: return initDecryption2();
	}
	return false;
}

bool decryptBook(const char *bookIn, const char *bookOut)
{
	switch (decryptionMethod)
	{
	case 1: return decryptBook1(bookIn, bookOut);
	case 2: return decryptBook2(bookIn, bookOut);
	}
	return false;
}