gcc -arch i386 -arch ppc -arch x86_64 -Wall -fPIC -O2 -c pukall.c
gcc -arch i386 -arch ppc -arch x86_64 -Wall -fPIC -O2 -c topaz.c
gcc -arch i386 -arch ppc -arch x86_64 -Wall -fPIC -O2 -c aes_cbc.c
gcc -arch i386 -arch ppc -arch x86_64 -dynamiclib -Wall -o libalfcrypto.dylib -dylib *.o
