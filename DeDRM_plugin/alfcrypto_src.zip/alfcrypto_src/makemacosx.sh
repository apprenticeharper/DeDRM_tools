# Under Mac OS X 10.6 to make universal build:
gcc -arch i386 -arch x86_64 -arch ppc -Wall -fPIC -O2 -c pukall.c
gcc -arch i386 -arch x86_64 -arch ppc -Wall -fPIC -O2 -c topaz.c
gcc -arch i386 -arch x86_64 -arch ppc -Wall -fPIC -O2 -c aes_cbc.c
gcc -arch i386 -arch x86_64 -arch ppc -dynamiclib -Wall -o libalfcrypto.dylib -dylib *.o

# If using Mac OS X 10.7 (without ppc support)
# gcc -arch i386 -arch x86_64 -Wall -fPIC -O2 -c pukall.c
# gcc -arch i386 -arch x86_64 -Wall -fPIC -O2 -c topaz.c
# gcc -arch i386 -arch x86_64 -Wall -fPIC -O2 -c aes_cbc.c
# gcc -arch i386 -arch x86_64 -dynamiclib -Wall -o libalfcrypto.dylib -dylib *.o


