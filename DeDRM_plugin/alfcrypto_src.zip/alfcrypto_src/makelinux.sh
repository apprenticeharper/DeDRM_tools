gcc -Wall -fPIC -O2 -c pukall.c
gcc -Wall -fPIC -O2 -c topaz.c
gcc -Wall -fPIC -O2 -c aes_cbc.c
gcc -shared -Wall -o libalfcrypto.so *.o

