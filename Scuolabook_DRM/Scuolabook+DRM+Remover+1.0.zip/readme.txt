How-to:
1) Make sure you can read all PDF files on Scuolabook Reader.
2) Run Scuolabook DRM Remover.
3) Get your free books from the directory where you started the program.

Note:
It is recommended to use Scuolabook version 2.0.1 and refuse all updates
because the encryption algorithm may change making this tool useless.

Hex